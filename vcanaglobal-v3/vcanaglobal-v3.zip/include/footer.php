<!-- footer area start  -->
<footer>
	<div class="footer_social">
	<nav class="left_social">
          <ul>
              <li><a href="https://www.facebook.com/Vcana-Global-LLP-105597571118536/?modal=admin_todo_tour%20" target="_blank">Facebook <i class="fab fa-facebook-f"></i></a></li>
              <li><a href="https://twitter.com/GlobalVcana" target="_blank">Twitter <i class="fab fa-twitter"></i></a></li>
              <li><a href="https://www.instagram.com/vcanaglobal" target="_blank">Instagram <i class="fab fa-instagram"></i></a></li>
          </ul>
      </nav>
		
		<nav class="right_social">
          <ul>
              <li><a href="#" target="_blank"><i class="fab fa-youtube"></i> Youtube </a></li>
              <li><a href="#" target="_blank"><i class="fab fa-whatsapp"></i> Whatsapp </a></li>
              <li><a href="#" target="_blank"><i class="fab fa-linkedin"></i> Linkedin</a></li>
          </ul>
      </nav>
		</div>
	<section class="footer-area">
		<div class="footer_background_overlay"></div>
		<div class="container">
			<div class="row wow fadeInUp">
				<div class="col-lg-4">
					<div class="footer-widget mb-40">
						<div class="footer-logo st-3 p-relative">
							<div class="footer-shape-st-3">
								<img src="assets/img/shape/foooter-shape-st-3.png" alt="">
							</div>
							<a href="index.php"><img src="assets/img/logo/logo.gif" alt=""></a>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="footer-widget mb-40">
						<div class="footer-widget-title">
							<h4>Navigation</h4>
						</div>
						<ul class="footer-list st-2 st-3">
							<li><a href="index.php" title="Home">Home</a>
							</li>
							<li><a href="#" title="About">About</a>
							</li>
							<li><a href="#" title="Our Service">Our Service</a>
							</li>
							<li><a href="#" title="Portfolio">Portfolio</a>
							</li>
							<li><a href="#" title="Blog">Blog</a>
							</li>
							<li><a href="#" title="contact">Contact</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="footer-widget mb-40 fw3">
						<div class="footer-widget-title">
							<h4>Social Link</h4>
						</div>
						<ul class="social-links clearfix">
							<li><a href="https://www.facebook.com/Vcana-Global-LLP-105597571118536/?modal=admin_todo_tour%20"><span class="face fab fa-facebook-f"></span></a>
							</li>
							<li><a href="https://twitter.com/GlobalVcana"><span class="twitt fab fa-twitter"></span></a>
							</li>
							<li><a href="https://www.linkedin.com/company/vcana-global-llp"><span class="link fab fa-linkedin"></span></a>
							</li>
							<li><a href="https://www.instagram.com/vcanaglobal"><span class="pint fab fa-instagram"></span></a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="footer-widget mb-40">
						<div class="footer-widget-title">
							<h4>Newsletter</h4>
						</div>
						<p>There are many variations of passages of Lorem Ipsum available, but the majority.</p>
						<form class="subscribe-form mb-30 mt-60 st-3">
							<input type="text" placeholder="Enter your email...">
							<button type="submit"><i class="fas fa-paper-plane"></i>Subscribe</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="copyright-area st-2">
		<div class="container">
			<div class="row wow fadeInUp align-items-center">
				<div class="col-lg-6 col-md-6">
					<div class="copyright-text st-2">
						<p>Vcana Global 2021©. All Rights Reserved.</p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6">
					<ul class="copyright-list f-right st-2">
						<li><a href="#">Terms & Conditions</a>
						</li>
						<li><a href="#">Privacy Policy</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>
 <!-- footer area end -->
<!--Scroll to top-->

