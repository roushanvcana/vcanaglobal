<!-- hero area start here -->
<section class="slider-area p-relative fix">
	<section class="position-relative">
      <div class="sec1"></div>
</section>
	<div class="banner_overlay"></div>
 <div class="slider-active swiper-container">
  <div class="swiper-wrapper">
   <div class="single-slider slider-height swiper-slide slider-overlay" data-swiper-autoplay="5000">
    <div class="slide-bg" data-background="assets/img/hero/banner2.jpg"></div>
    <div class="container">
     <div class="row">
      <div class="col-lg-9">
       <div class="hero-content">
        <h1 data-animation="fadeInUp" data-delay=".9s"><span class="color_org">IGNITE</span> Your <span class="color_blue">Business</span></h1>
        <div class="hero-content-btn" data-animation="fadeInUp" data-delay="1.1s"> <a href="#" class="theme-btn btn-style-one"><span class="txt">Get in Touch</span></a> </div>
        <div class="hero-content-btn" data-animation="fadeInUp" data-delay="1.1s"> <a href="#" class="theme-btn btn-style-three"><span class="txt">See Services</span></a> </div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="single-slider slider-height swiper-slide slider-overlay" data-swiper-autoplay="5000">
    <div class="slide-bg" data-background="assets/img/hero/banner3.jpg"></div>
    <div class="container">
     <div class="row">
      <div class="col-lg-9">
       <div class="hero-content">
        <h1 data-animation="fadeInUp" data-delay=".9s"><span class="color_org">IGNITE</span> Your <span class="color_blue">Business</span></h1>
        <div class="hero-content-btn" data-animation="fadeInUp" data-delay="1.1s"> <a href="#" class="theme-btn btn-style-one"><span class="txt">Get in Touch</span></a> </div>
        <div class="hero-content-btn" data-animation="fadeInUp" data-delay="1.1s"> <a href="#" class="theme-btn btn-style-three"><span class="txt">See Services</span></a> </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>
 
 </div>
  </section>
<!-- hero area end here --> 